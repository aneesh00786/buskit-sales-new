import 'dart:developer';

import 'package:busskit_salesexecutive/common/custom_fonts.dart';
import 'package:busskit_salesexecutive/ui/components/category_filter/product_list/model/cart_model.dart';
import 'package:busskit_salesexecutive/ui/utills/extentions/string_extention.dart';
import 'package:enefty_icons/enefty_icons.dart';
import 'package:flutter/material.dart';

class GroupedItemDataRows {
  static List<DataRow> getRows({
    required List<CartItem> groupedItems,
    required double fontSize,
    required double availableWidth,
    required BuildContext context,
    required Function(CartItem groupedItem, String totalPrice, double fontSize,
            double availableWidth)
        productQuantityManager,
    required Function(BuildContext context, CartItem groupedItem,
            List<CartItem> groupedItems)
        deleteConfirmationDialogue,
    required Function calculateAmount,
  }) {
    return groupedItems.map((groupedItem) {
      final taxDiscountAmount = ((groupedItem.detail.tax ?? 0.0) *
          ((groupedItem.isPack == true || groupedItem.detail.packtype == 'Pack')
              ? (groupedItem.detail.pieces?.toDouble() ?? 1) *
                  groupedItem.detail.count.toDouble()
              : groupedItem.detail.count.toDouble()) *
          ((double.tryParse(groupedItem.detail.discount?.toString() ?? '0') ??
                  0.0) /
              100));
      final discountPrice =
          (((double.tryParse(groupedItem.detail.sellPrice?.toString() ?? '0') ??
                      0.0) *
                  ((double.tryParse(
                              groupedItem.detail.discount?.toString() ?? '0') ??
                          0.0) /
                      100)) *
              ((groupedItem.isPack == true ||
                      groupedItem.detail.packtype == 'Pack')
                  ? (groupedItem.detail.pieces?.toDouble() ?? 1) *
                      groupedItem.detail.count.toDouble()
                  : groupedItem.detail.count.toDouble()));
      final tax = groupedItem.detail.tax! *
          (groupedItem.isPack == true || groupedItem.detail.packtype == 'Pack'
              ? groupedItem.detail.pieces! * groupedItem.detail.count
              : 1);
      log('Tax Discount Row Item : $discountPrice');
      log('Tax Discount Row Item : $taxDiscountAmount');
      log('Draft id is Contains or not? == ${groupedItem.draftId}');
      log('Incl Tax  == ${groupedItem.detail.inclTax}');
      log('Discount Amount on Get Rows : ${groupedItem.detail.discount}');
      return DataRow(
        cells: [
          DataCell(
            SizedBox(
              width: 30,
              child: StatefulBuilder(
                builder: (context, setState) {
                  return Checkbox(
                    value: groupedItem.isChecked,
                    onChanged: (bool? value) {
                      setState(() {
                        groupedItem.isChecked = value ?? false;
                        log("Checkbox for ${groupedItem.detail.variationName} is ${groupedItem.isChecked ?? true ? 'checked' : 'unchecked'}");
                      });
                      calculateAmount();
                    },
                  );
                },
              ),
            ),
          ),
          DataCell(
            TableContent(
              content:
                  '${groupedItem.detail.variationName} ${groupedItem.detail.unitType}',
              fontSize: fontSize,
            ),
          ),
          DataCell(TableContent(
              fontSize: fontSize,
              maxLines: 1,
              content: formatAmount(groupedItem.detail.sellPrice ?? '0'))),
          DataCell(TableContent(
              fontSize: fontSize,
              maxLines: 2,
              content: (groupedItem.detail.packtype == 'Pack' ||
                      groupedItem.isPack == true)
                  ? '${groupedItem.detail.packtype} \n(${groupedItem.detail.pieces} Pcs)'
                  : 'Pcs')),
          DataCell(
            TableContent(
                fontSize: fontSize,
                maxLines: 1,
                content: formatAmount(
                  (double.tryParse(groupedItem.detail.sellPrice?.toString() ??
                              '0') ??
                          0.0) *
                      ((groupedItem.detail.packtype == 'Pack' ||
                              groupedItem.isPack == true)
                          ? (groupedItem.detail.pieces ?? 1)
                          : 1),
                )),
          ),
          DataCell(
            TableContent(
              maxLines: 1,
              fontSize: fontSize,
              content: formatAmount(
                discountPrice,
              ),
            ),
          ),
          DataCell(
            TableContent(
                maxLines: 1,
                fontSize: fontSize,
                content: formatAmount(tax - taxDiscountAmount)),
          ),
          DataCell(
            Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(minWidth: 50, maxWidth: 100),
                child: productQuantityManager(
                  groupedItem,
                  (groupedItem.detail.inclTax == 'incl_tax'
                      ? groupedItem.totalPrice.toString()
                      : (groupedItem.totalPrice + groupedItem.detail.tax!)
                          .toString()),
                  fontSize,
                  availableWidth,
                ),
              ),
            ),
          ),
          DataCell(
            Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(minWidth: 50, maxWidth: 100),
                child: CustomText(
                  content: formatAmount(groupedItem.totalPrice),
                  textAlign: TextAlign.right,
                  fontSize: fontSize,
                  maxLine: 1,
                ),
              ),
            ),
          ),
          DataCell(
            Center(
              child: SizedBox(
                width: 30,
                child: IconButton(
                  icon: const Icon(
                    EneftyIcons.trash_outline,
                    color: Colors.red,
                    size: 25,
                  ),
                  onPressed: () {
                    deleteConfirmationDialogue(
                        context, groupedItem, groupedItems);
                  },
                ),
              ),
            ),
          ),
        ],
      );
    }).toList();
  }
}

// ignore: must_be_immutable
class TableContent extends StatelessWidget {
  double fontSize;
  String content;
  int maxLines;
  TableContent(
      {super.key,
      required this.fontSize,
      required this.content,
      this.maxLines = 2});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(minWidth: 50, maxWidth: 100),
        child: CustomText(
          content: content,
          textAlign: TextAlign.center,
          fontSize: fontSize,
          maxLine: maxLines,
        ),
      ),
    );
  }
}
