//cart_model

import 'package:busskit_salesexecutive/ui/components/category_filter/product_list/model/product_model.dart';
import 'package:hive_flutter/adapters.dart';
part 'cart_model.g.dart';

@HiveType(typeId: 1)
class CartItem extends HiveObject {
  @HiveField(0)
  final Detail detail;

  @HiveField(1)
  final String productName;

  @HiveField(2)
  double totalPrice;

  @HiveField(3)
  final bool? isPack;

  @HiveField(4)
  int? count;

  @HiveField(5)
  String? customerId;

  @HiveField(6)
  String? cartId;

  @HiveField(7)
  String? draftId;

  @HiveField(8)
  bool? isChecked;

  @HiveField(9)
  num? draftTotal;

  @HiveField(10)
  String? salesmanId;

  @HiveField(11)
  bool? boxType;

  @HiveField(12)
  int? catId;



  CartItem({
    required this.detail,
    required this.productName,
    required this.totalPrice,
    this.isPack,
    this.count,
    this.customerId,
    this.cartId,
    this.draftId,
    this.isChecked = true,
    this.draftTotal,
    this.salesmanId,
    this.boxType,
    this.catId,
  });

factory CartItem.fromJson(Map<String, dynamic> json) {
  return CartItem(
    detail: Detail.fromJson(json['detail'] ?? {}),
    productName: json['productName'] ?? '',
    totalPrice: json['totalPrice']?.toDouble() ?? 0.0,
    isPack: json['isPack'] as bool?,
    count: json['count'] as int?,
    customerId: json['customer_id'] as String?,
    cartId: json['cart_id'] as String?,
    draftId: json['id'] as String?,
    isChecked: json['isChecked'] as bool? ?? true,
    draftTotal: json['order_total'] as num? ?? 0,
    salesmanId: json['salesman_id'] as String?,
    boxType: json['boxType'],
    catId: json['categories_id'],
  );
}


  Map<String, dynamic> toJson() {
    return {
      'detail': detail.toJson(),
      'productName': productName,
      'totalPrice': totalPrice,
      'isPack': isPack,
      'count': count,
      'customer_id': customerId,
      'cart_id': cartId,
      'id': draftId,
      'isChecked': isChecked,
      'order_total': draftTotal,
      'salesman_id':salesmanId,
      'boxType':boxType,
      'categories_id':catId
    };
  }

  CartItem copyWith({
    Detail? detail,
    String? productName,
    double? totalPrice,
    bool? isPack,
    int? count,
    String? customerId,
    String? cartId,
    String? draftId,
    bool? isChcked,
    num?draftTotal,
    String?salesmanId,
    bool?boxType,
    int? catId,
  }) {
    return CartItem(
        detail: detail ?? this.detail,
        productName: productName ?? this.productName,
        totalPrice: totalPrice ?? this.totalPrice,
        isPack: isPack ?? this.isPack,
        count: count ?? this.count,
        customerId: customerId ?? this.customerId,
        cartId: cartId ?? this.cartId,
        draftId: draftId ?? this.draftId,
        isChecked: isChcked ?? isChecked,
        draftTotal: draftTotal ?? this.draftTotal,
        salesmanId: salesmanId ?? this.salesmanId,
        boxType: boxType ?? this.boxType,
        catId: catId ?? this.catId,
        
        );
  }
}
