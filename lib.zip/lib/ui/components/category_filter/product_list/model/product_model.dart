//Product Model

import 'package:hive_flutter/hive_flutter.dart';

part 'product_model.g.dart';

@HiveType(typeId: 2)
class ProductModel {
  @HiveField(0)
  int? id;

  @HiveField(1)
  String? productId;

  @HiveField(2)
  String? brandname;

  @HiveField(3)
  String? productName;

  @HiveField(4)
  String? description;

  @HiveField(5)
  String? reasonBySalesman;

  @HiveField(6)
  String? imageUrl;

  @HiveField(7)
  String? inclTax;

  @HiveField(8)
  int? status;

  @HiveField(9)
  String? scid;

  @HiveField(10)
  int? catId;

  @HiveField(11)
  int? companyId;

  @HiveField(12)
  String? stock;

  @HiveField(13)
  List<Detail>? detail;

  ProductModel({
    this.id,
    this.productId,
    this.brandname,
    this.productName,
    this.description,
    this.reasonBySalesman,
    this.imageUrl,
    this.inclTax,
    this.status,
    this.scid,
    this.catId,
    this.companyId,
    this.stock,
    this.detail,
  });

  ProductModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    productId = json['product_id'];
    brandname = json['brandname'];
    productName = json['product_name'];
    description = json['description'];
    reasonBySalesman = json['reason_by_salesman'];
    imageUrl = json['image_url'];
    inclTax = json['incl_tax'];
    status = json['status'];
    scid = json['scid'];
    catId = json['catId'];
    companyId = json['company_id'];
    stock = json['stock'];
    if (json['detail'] != null) {
      detail = <Detail>[];
      json['detail'].forEach((v) {
        detail!.add(Detail.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data['id'] = id;
    data['product_id'] = productId;
    data['brandname'] = brandname;
    data['product_name'] = productName;
    data['description'] = description;
    data['reason_by_salesman'] = reasonBySalesman;
    data['image_url'] = imageUrl;
    data['incl_tax'] = inclTax;
    data['status'] = status;
    data['scid'] = scid;
    data['catId'] = catId;
    data['company_id'] = companyId;
    data['stock'] = stock;
    if (detail != null) {
      data['detail'] = detail!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

@HiveType(typeId: 0)
class Detail {
  @HiveField(0)
  int? id;

  @HiveField(1)
  int? companyId;

  @HiveField(2)
  String? productId;

  @HiveField(3)
  String? variationId;

  @HiveField(4)
  String? inNo;

  @HiveField(5)
  String? barcode;

  @HiveField(6)
  String? variationName;

  @HiveField(7)
  String? unitType;

  @HiveField(8)
  String? price;

  @HiveField(9)
  String? sellPrice;

  @HiveField(10)
  num? tax;

  @HiveField(11)
  String? packtype;

  @HiveField(12)
  num? pieces;

  @HiveField(13)
  num? stock;

  @HiveField(14)
  num? lowstock;

  @HiveField(15)
  num? fullstock;

  @HiveField(16)
  String? imageUrl;

  @HiveField(17)
  int? status;

  @HiveField(18)
  int? vStatus;

  @HiveField(21)
  num count;

  @HiveField(22)
  String? saleBy = 'Pack';

  @HiveField(23)
  num? totalPrice = 0.0;

  @HiveField(24)
  num? sellingPrice;

  @HiveField(25)
  num? packPrice;

  @HiveField(26)
  num? sellingPackPrice;

  @HiveField(27)
  String? inclTax;

  @HiveField(28)
  num? initialQuantity;

  @HiveField(29)
  num? unitTax;

  @HiveField(30)
  String? pack;

  @HiveField(31)
  num? discount;

  @HiveField(32)
  num? totaltax;


  Detail({
    this.id,
    this.companyId,
    this.productId,
    this.variationId,
    this.inNo,
    this.barcode,
    this.variationName,
    this.unitType,
    this.price,
    this.sellPrice,
    this.tax,
    this.packtype,
    this.pieces,
    this.stock,
    this.lowstock,
    this.fullstock,
    this.imageUrl,
    this.status,
    this.vStatus,
    this.count = 0,
    this.saleBy,
    this.totalPrice,
    this.sellingPrice,
    this.packPrice,
    this.sellingPackPrice,
    this.inclTax,
    this.initialQuantity,
    this.unitTax,
    this.pack,
    this.discount,
    this.totaltax,
  });
  Detail copyWith({
    int? id,
    int? companyId,
    String? productId,
    String? variationId,
    String? inNo,
    String? barcode,
    String? variationName,
    String? unitType,
    String? price,
    String? sellPrice,
    num? tax,
    String? packtype,
    num? pieces,
    num? stock,
    num? lowstock,
    num? fullstock,
    String? imageUrl,
    int? status,
    int? vStatus,
    num? count,
    String? saleBy,
    num? totalPrice,
    num? sellingPrice,
    num? packPrice,
    num? sellingPackPrice,
    String? inclTax,
    num? initialQuantity,
    num? unitTax,
    String? pack,
    num? discount,
    num? totalTax,
  }) {
    return Detail(
      id: id ?? this.id,
      companyId: companyId ?? this.companyId,
      productId: productId ?? this.productId,
      variationId: variationId ?? this.variationId,
      inNo: inNo ?? this.inNo,
      barcode: barcode ?? this.barcode,
      variationName: variationName ?? this.variationName,
      unitType: unitType ?? this.unitType,
      price: price ?? this.price,
      sellPrice: sellPrice ?? this.sellPrice,
      tax: tax ?? this.tax,
      packtype: packtype ?? this.packtype,
      pieces: pieces ?? this.pieces,
      stock: stock ?? this.stock,
      lowstock: lowstock ?? this.lowstock,
      fullstock: fullstock ?? this.fullstock,
      imageUrl: imageUrl ?? this.imageUrl,
      status: status ?? this.status,
      vStatus: vStatus ?? this.vStatus,
      count: count ?? this.count,
      saleBy: saleBy ?? this.saleBy,
      totalPrice: totalPrice ?? this.totalPrice,
      sellingPrice: sellingPrice ?? this.sellingPrice,
      packPrice: packPrice ?? this.packPrice,
      sellingPackPrice: sellingPackPrice ?? this.sellingPackPrice,
      inclTax: inclTax ?? this.inclTax,
      initialQuantity: initialQuantity ?? this.initialQuantity,
      unitTax: unitTax ?? this.unitTax,
      pack: pack ?? this.pack,
      discount: discount ?? this.discount,
      totaltax: totaltax ?? totaltax,
    );
  }

  Detail.fromJson(Map<String, dynamic> json)
      : id = json['id'],
        companyId = json['company_id'],
        productId = json['product_id'],
        variationId = json['variation_id'],
        inNo = json['in_no'],
        barcode = json['barcode'],
        variationName = json['variation_name'],
        unitType = json['unitType'],
        price = json['price'],
        sellPrice = json['sell_price'],
        tax = json['tax'],
        packtype = json['packtype'],
        pieces = json['pieces'],
        stock = json['stock'],
        lowstock = json['lowstock'],
        fullstock = json['fullstock'],
        imageUrl = json['image_url'],
        status = json['status'],
        vStatus = json['v_status'],
        count = json['count'] ?? 0.0,
        saleBy = json['saleBy'],
        totalPrice = json['totalPrice'],
        sellingPrice = json['selling_price'],
        packPrice = json['pack_price'],
        sellingPackPrice = json['selling_pack_price'],
        inclTax = json['incl_tax'],
        initialQuantity = json['quantity'],
        unitTax = json['unit_tax'],
        pack = json['packtype'],
        discount = json['discount'],
        totaltax = json['total_tax'];

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data['id'] = id;
    data['company_id'] = companyId;
    data['product_id'] = productId;
    data['variation_id'] = variationId;
    data['in_no'] = inNo;
    data['barcode'] = barcode;
    data['variation_name'] = variationName;
    data['unitType'] = unitType;
    data['price'] = price;
    data['sell_price'] = sellPrice;
    data['tax'] = tax;
    data['packtype'] = packtype;
    data['pieces'] = pieces;
    data['stock'] = stock;
    data['lowstock'] = lowstock;
    data['fullstock'] = fullstock;
    data['image_url'] = imageUrl;
    data['status'] = status;
    data['v_status'] = vStatus;
    data['count'] = count;
    data['saleBy'] = saleBy;
    data['totalPrice'] = totalPrice;
    data['selling_price'] = sellingPrice;
    data['pack_price'] = packPrice;
    data['selling_pack_price'] = sellingPackPrice;
    data['incl_tax'] = inclTax;
    data['quantity'] = initialQuantity;
    data['unit_tax'] = unitTax;
    data['packType'] = pack;
    data['discount'] = discount;
    data['total_tax'] = totaltax;
    return data;
  }
}
