import 'dart:developer';

import 'package:busskit_salesexecutive/api_handler/api_constants.dart';
import 'package:busskit_salesexecutive/common/custom_fonts.dart';
import 'package:busskit_salesexecutive/ui/components/category_filter/order_taking/local_database/cart_database.dart';
import 'package:busskit_salesexecutive/ui/components/category_filter/product_list/model/product_model.dart';
import 'package:busskit_salesexecutive/ui/components/color/colors.dart';
import 'package:busskit_salesexecutive/ui/utills/extentions/string_extention.dart';
import 'package:busskit_salesexecutive/ui/view/ui/customer_and_orders/cus_provider/cus_provider.dart';
import 'package:busskit_salesexecutive/ui/view/ui/customer_and_orders/customer_and_orders_controller.dart';
import 'package:busskit_salesexecutive/ui/view/ui/products/products_controller.dart';
import 'package:enefty_icons/enefty_icons.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

class ProductVariantDialogue extends StatefulWidget {
  final int index;
  final ProductModel product;
  final List<ProductModel> productList;
  final VoidCallback onDone;
  final List<Detail> detailsCopy;
  final ProductsController productController;

  const ProductVariantDialogue({
    super.key,
    required this.index,
    required this.product,
    required this.productList,
    required this.onDone,
    required this.detailsCopy,
    required this.productController,
  });

  @override
  State<ProductVariantDialogue> createState() => _ProductVariantDialogueState();
}

class _ProductVariantDialogueState extends State<ProductVariantDialogue> {
  CustomerAndOrderController customerAndOrderController =
      Get.put(CustomerAndOrderController());
  List<String> droDownItem = ['Pack', 'Pcs'];
  double totalPrice = 0.0;
  late List<int> localCounts;
  @override
  void initState() {
    super.initState();
    localCounts = List<int>.filled(widget.detailsCopy.length, 0);
    final cartProvider = Provider.of<CustomersProvider>(context, listen: false);
    cartProvider.getCartItemCounts(
        customerAndOrderController.customerId.value.isNotEmpty
            ? customerAndOrderController.customerId.value
            : widget.productController.selectedCustomerId.value);
    CartDatabaseManager().addListener(() {
      cartProvider.updateCartCount(
          customerAndOrderController.customerId.value.isNotEmpty
              ? customerAndOrderController.customerId.value
              : widget.productController.selectedCustomerId.value);
    });
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;
    return Dialog(
      insetPadding: const EdgeInsets.all(40),
      backgroundColor: white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20.0),
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final fontSize = constraints.maxWidth / 55;
          final iconSize = constraints.maxWidth / 45;
          final columnSpacing = screenWidth / 40;
          return SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Stack(
                  children: [
                    Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: screenWidth * 0.1),
                      child: Container(
                        height: 12,
                        decoration: const BoxDecoration(
                            color: primaryColor,
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(100),
                                bottomRight: Radius.circular(100))),
                        width: double.infinity,
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: const BoxDecoration(
                            color: primaryColor,
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(20),
                              bottomRight: Radius.circular(40),
                            ),
                          ),
                          child: Padding(
                            padding: EdgeInsets.only(
                              left: screenWidth * 0.02,
                              right: screenWidth * 0.1,
                            ),
                            child: CustomText(
                              content: 'Product Variant',
                              fontSize: screenWidth * 0.03,
                              fontWeight: FontWeight.bold,
                              fontFamily: fontFamilyName,
                              color: Colors.white,
                            ),
                          ),
                        ),
                        IconButton(
                          icon: const CircleAvatar(
                            radius: 15,
                            child: Icon(
                              Icons.close_rounded,
                              color: Colors.black,
                              size: 14,
                            ),
                          ),
                          padding: EdgeInsets.zero,
                          onPressed: () {
                            Navigator.pop(context);
                          },
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: screenHeight * 0.02),
                Padding(
                  padding: const EdgeInsets.only(left: 20),
                  child: Row(
                    children: [
                      Hero(
                        tag: 'product_image',
                        child: Container(
                          height: screenHeight * 0.12,
                          width: screenHeight * 0.12,
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              fit: BoxFit.cover,
                              image: widget.product.imageUrl == null
                                  ? const AssetImage('assets/images/otp.png')
                                      as ImageProvider
                                  : NetworkImage(
                                      '${ApiConstants.imageBaseUrl}/${widget.product.imageUrl}' 
                                          ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 20,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: constraints.maxWidth < 800
                                ? screenWidth * 0.55
                                : screenWidth * 0.65,
                            child: CustomText(
                              content: widget.product.productName ?? '',
                              fontWeight: FontWeight.bold,
                              fontSize: screenWidth * 0.03,
                            ),
                          ),
                          CustomText(
                            content: 'Product ID : ${widget.product.id}',
                            fontSize: screenWidth * 0.02,
                          ),
                          SizedBox(
                            width: constraints.maxWidth < 800
                                ? screenWidth * 0.55
                                : screenWidth * 0.65,
                            child: CustomText(
                              content: widget.product.description ?? '',
                              fontWeight: FontWeight.w500,
                              color: Colors.grey,
                              fontSize: screenWidth * 0.015,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(height: screenHeight * 0.02),
                SizedBox(
                  width: screenWidth * 0.85,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: SizedBox(
                      width: screenWidth * 0.85,
                      child: DataTable(
                        headingRowHeight: screenHeight * 0.03,
                        // ignore: deprecated_member_use
                        dataRowHeight: screenHeight * 0.05,
                        columnSpacing: columnSpacing,
                        headingRowColor:
                            const WidgetStatePropertyAll(secondaryColor),
                        columns: [
                          DataColumn(
                            label: Expanded(
                              child: Center(
                                child: CustomText(
                                  content: 'Variant',
                                  color: black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: fontSize,
                                ),
                              ),
                            ),
                          ),
                          DataColumn(
                            label: Expanded(
                              child: Center(
                                child: CustomText(
                                  content: 'Unit',
                                  color: black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: fontSize,
                                ),
                              ),
                            ),
                          ),
                          DataColumn(
                            label: Expanded(
                              child: Center(
                                child: CustomText(
                                  content: 'Sale price',
                                  color: black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: fontSize,
                                ),
                              ),
                            ),
                          ),
                          DataColumn(
                            label: Expanded(
                              child: Center(
                                child: CustomText(
                                  content: 'Tax',
                                  color: black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: fontSize,
                                ),
                              ),
                            ),
                          ),
                          DataColumn(
                            label: Expanded(
                              child: Center(
                                child: CustomText(
                                  content: 'Pack',
                                  color: black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: fontSize,
                                ),
                              ),
                            ),
                          ),
                          DataColumn(
                            label: Expanded(
                              child: Center(
                                child: CustomText(
                                  content: 'Total',
                                  color: black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: fontSize,
                                ),
                              ),
                            ),
                          ),
                          DataColumn(
                            label: Expanded(
                              child: Center(
                                child: CustomText(
                                  content: 'Stock',
                                  color: black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: fontSize,
                                ),
                              ),
                            ),
                          ),
                          DataColumn(
                            label: Expanded(
                              child: Center(
                                child: CustomText(
                                  content: 'Sale by',
                                  color: black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: fontSize,
                                ),
                              ),
                            ),
                          ),
                          DataColumn(
                            label: Expanded(
                              child: Center(
                                child: CustomText(
                                  content: 'Quantity',
                                  color: black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: fontSize,
                                ),
                              ),
                            ),
                          ),
                        ],
                        rows: List.generate(
                          widget.detailsCopy.length,
                          (i) {
                            Detail detail = widget.detailsCopy[i];
                            return DataRow(
                              cells: [
                                DataCell(Center(
                                    child: CustomText(
                                  content: detail.variationName ?? '',
                                  fontSize: fontSize,
                                ))),
                                DataCell(CustomText(
                                    content: '${detail.unitType}',
                                    fontSize: fontSize)),
                                DataCell(Center(
                                    child: CustomText(
                                  content: formatAmount(detail.sellPrice),
                                  fontSize: fontSize,
                                ))),
                                DataCell(Center(
                                    child: CustomText(
                                  content: formatAmount(detail.tax),
                                  fontSize: fontSize,
                                ))),
                                DataCell(Center(
                                    child: CustomText(
                                  content: '${detail.pieces ?? 0}',
                                  fontSize: fontSize,
                                ))),
                                DataCell(Center(
                                    child: CustomText(
                                  content:
                                      formatAmount(detail.sellingPackPrice),
                                  fontSize: fontSize,
                                ))),
                                DataCell(
                                  Center(
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: detail.stock == 0
                                            ? Colors.red
                                            : detail.stock! < detail.lowstock!
                                                ? Colors.orange
                                                : Colors.green,
                                        shape: BoxShape.circle,
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(1.0),
                                        child: Icon(
                                          detail.stock == 0
                                              ? Icons.close
                                              : detail.stock! < detail.lowstock!
                                                  ? Icons.warning_amber_rounded
                                                  : Icons.check,
                                          color: Colors.white,
                                          size: 14.0,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                DataCell(
                                  Center(
                                    child: DropdownButton<String>(
                                      dropdownColor: white,
                                      value: detail.saleBy ?? droDownItem[0],
                                      items: droDownItem
                                          .map<DropdownMenuItem<String>>(
                                              (String value) {
                                        return DropdownMenuItem<String>(
                                          value: value,
                                          child: CustomText(
                                            content: value,
                                            fontSize: fontSize,
                                          ),
                                        );
                                      }).toList(),
                                      onChanged: (String? newValue) {
                                        setState(() {
                                          detail.saleBy = newValue;
                                        });
                                      },
                                    ),
                                  ),
                                ),
                                DataCell(
                                  Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      color: const Color.fromARGB(255, 240, 239, 239),
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Container(
                                          decoration: const BoxDecoration(
                                            color: primaryColor,
                                            borderRadius: BorderRadius.only(
                                              topLeft: Radius.circular(5),
                                              bottomLeft: Radius.circular(5),
                                            ),
                                          ),
                                          child: InkWell(
                                            onTap: () {
                                              setState(() {
                                                if (localCounts[i] > 0) {
                                                  localCounts[i]--;
                                                }
                                              });
                                            },
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(2.5),
                                              child: Icon(
                                                Icons.remove,
                                                color: Colors.white,
                                                size: iconSize,
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 8),
                                        CustomText(
                                          content:
                                              localCounts[i].toStringAsFixed(0),
                                          fontSize: fontSize,
                                        ),
                                        const SizedBox(width: 8),
                                        Container(
                                          decoration: const BoxDecoration(
                                            color: primaryColor,
                                            borderRadius: BorderRadius.only(
                                              topRight: Radius.circular(5),
                                              bottomRight: Radius.circular(5),
                                            ),
                                          ),
                                          child: InkWell(
                                            onTap: () {
                                              setState(() {
                                                detail.saleBy ??= 'Pack';
                                                if (detail.stock == 0) {
                                                  showDialog(
                                                    context: context,
                                                    builder:
                                                        (BuildContext context) {
                                                      return AlertDialog(
                                                        shape:
                                                            RoundedRectangleBorder(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(15),
                                                        ),
                                                        backgroundColor:
                                                            Colors.white,
                                                        title: const Row(
                                                          children: [
                                                            Icon(
                                                                Icons
                                                                    .info_outline,
                                                                color:
                                                                    Colors.red),
                                                            SizedBox(
                                                                width: 8),
                                                            Text(
                                                              'Out of Stock',
                                                              style: TextStyle(
                                                                fontSize: 20,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                color: Colors
                                                                    .black,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                        content: const Column(
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          children: [
                                                            Text(
                                                              'This item is out of stock.',
                                                              style: TextStyle(
                                                                fontSize: 16,
                                                                color: Colors
                                                                    .black87,
                                                              ),
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                            ),
                                                            SizedBox(
                                                                height: 10),
                                                            Text(
                                                              'Do you want to add this as a pre-order?',
                                                              style: TextStyle(
                                                                fontSize: 16,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                color: Colors
                                                                    .black,
                                                              ),
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                            ),
                                                          ],
                                                        ),
                                                        actions: [
                                                          ElevatedButton(
                                                            onPressed: () {
                                                              Navigator.of(
                                                                      context)
                                                                  .pop();
                                                            },
                                                            style:
                                                                ElevatedButton
                                                                    .styleFrom(
                                                              backgroundColor:
                                                                  Colors
                                                                      .redAccent,
                                                              shape:
                                                                  RoundedRectangleBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            8),
                                                              ),
                                                            ),
                                                            child: const Text(
                                                              'No',
                                                              style: TextStyle(
                                                                color: Colors
                                                                    .white,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                              ),
                                                            ),
                                                          ),
                                                          ElevatedButton(
                                                            onPressed: () {
                                                              setState(() {
                                                                localCounts[
                                                                    i]++;
                                                              });
                                                              Navigator.of(
                                                                      context)
                                                                  .pop();
                                                            },
                                                            style:
                                                                ElevatedButton
                                                                    .styleFrom(
                                                              backgroundColor:
                                                                  Colors.green,
                                                              shape:
                                                                  RoundedRectangleBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            8),
                                                              ),
                                                            ),
                                                            child: const Text(
                                                              'Yes',
                                                              style: TextStyle(
                                                                color: Colors
                                                                    .white,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      );
                                                    },
                                                  );
                                                } else if (detail.stock == 0) {
                                                  localCounts[i]++;
                                                } else {
                                                  localCounts[i]++;
                                                }
                                              });
                                            },
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(2.5),
                                              child: Icon(
                                                Icons.add,
                                                color: Colors.white,
                                                size: iconSize,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: screenHeight * 0.02),
                Padding(
                  padding: EdgeInsets.symmetric(
                    vertical: screenHeight * 0.03,
                    horizontal: screenWidth * 0.025,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      ElevatedButton(
                          onPressed: () async {
                            final customerId = customerAndOrderController
                                    .customerId.value.isNotEmpty
                                ? customerAndOrderController.customerId.value
                                : widget
                                    .productController.selectedCustomerId.value;

                            if ((customerAndOrderController
                                    .customerId.value.isNotEmpty) ||
                                (widget.productController.selectedCustomerName
                                    .value.isNotEmpty)) {
                              for (var i = 0;
                                  i < widget.detailsCopy.length;
                                  i++) {
                                Detail detail = widget.detailsCopy[i];
                                if (localCounts[i] > 0) {
                                  final bool isPack = detail.saleBy == 'Pack';
                                  await CartDatabaseManager().addToCart(
                                    customerId: customerId,
                                    localCount: localCounts[i],
                                    detail: detail,
                                    isPack: isPack,
                                    productName:
                                        widget.product.productName ?? '',
                                    inclTax: widget.product.inclTax ?? '',
                                    isChcked: true,
                                    catId: widget.product.catId??0,
                                  );
                                  log('Product added to cart or draft with ID: ${detail.variationId}');
                                } else {
                                  log('Cannot add product with ID: ${detail.variationId} because the count is zero or less.');
                                }
                              }
                              WidgetsBinding.instance.addPostFrameCallback((_) {
                                final cartProvider =
                                    Provider.of<CustomersProvider>(context,
                                        listen: false);
                                cartProvider.updateCartCount(customerId);
                                cartProvider.getCartItemCounts(customerId);
                                widget.onDone();
                                Navigator.pop(context);
                              });
                            } else {
                              showDialog(
                                context: context,
                                builder: (context) {
                                  return AlertDialog(
                                    actions: [
                                      const SizedBox(height: 20),
                                      const Center(
                                          child: Icon(
                                              Icons.warning_amber_outlined,
                                              size: 50,
                                              color: Colors.orange)),
                                      const SizedBox(height: 20),
                                      Center(
                                          child: CustomText(
                                              content:
                                                  "Please Select a Customer",
                                              fontSize: 18)),
                                      TextButton(
                                        onPressed: () {
                                          Navigator.pop(context);
                                        },
                                        child: CustomText(
                                            content: "Ok", color: primaryColor),
                                      ),
                                    ],
                                  );
                                },
                              );
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: primaryButtonColor,
                            padding: EdgeInsets.symmetric(
                              horizontal: screenWidth * 0.04,
                              vertical: screenHeight * 0.01,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                          child: Row(
                            children: [
                              CustomText(
                                content: "Add to Cart",
                                fontSize: screenWidth * 0.02,
                                color: Colors.white,
                              ),
                              SizedBox(
                                width: screenWidth * 0.02,
                              ),
                              Icon(
                                EneftyIcons.shopping_cart_outline,
                                size: screenWidth * 0.03,
                                color: white,
                              )
                            ],
                          )),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void incrementCount(int index) {
    setState(() {
      localCounts[index]++;
    });
  }

  void decrementCount(int index) {
    setState(() {
      if (localCounts[index] > 0) {
        localCounts[index]--;
      }
    });
  }
}
