import 'dart:developer';
import 'package:busskit_salesexecutive/ui/components/category_filter/order_taking/view/order_taking.dart';
import 'package:busskit_salesexecutive/ui/view/ui/customer_and_orders/customer_dashbord/customer_dashbord_screen.dart';
import 'package:busskit_salesexecutive/ui/view/ui/products/products_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ProductMiddelWidget extends StatelessWidget {
  final ProductsController productsController;

  const ProductMiddelWidget({super.key, required this.productsController});
  @override
  Widget build(BuildContext context) {
    return Obx(() {
      log('isReached state: ${productsController.isReached.value}');
      return productsController.isReached.value
          ? const CustomerDachScreen(
              isFromCalendar: true,
            )
          : OrderTaking(
              productsController: productsController,
              isDirectDialogue: true,
            );
    });
  }
}
